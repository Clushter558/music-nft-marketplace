// Dashboard.js
import React from 'react';
import { Container, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import otherPic from './other-pic.png';
import './Dashboard.css';

const Dashboard = () => {
  return (
    <Container className="dashboard-container">
      <div className="dashboard-content">
        <div className="text-container">
          <p className="dashboard-text">
            <span className="original-text">Welcome to the Music NFT Marketplace</span><br />
            {/* Link buttons to their respective routes */}
            <Link to="/">
              <Button variant="primary" className="action-button">BUY</Button>
            </Link><br />
            <Link to="/my-tokens">
              <Button variant="secondary" className="action-button">VIEW</Button>
            </Link><br />
            <Link to="/my-resales">
              <Button variant="success" className="action-button">SELL</Button>
            </Link><br />
          </p>
        </div>
        <img src={otherPic} alt="Other Picture" className="other-pic" />
      </div>
    </Container>
  );
};

export default Dashboard;
